const productSelect = document.getElementById("product");

document.querySelectorAll("[data-product]").forEach(btn => {
  btn.addEventListener("click", () => {
    productSelect.value = btn.dataset.product;
  });
});

document.getElementById("orderForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const city = document.getElementById("city").value.trim();
  const address = document.getElementById("address").value.trim();
  const product = document.getElementById("product").value;
  const qty = document.getElementById("qty").value;

  const total = Number(qty) * 69;
  const message =
`Bonjour TI Brothers 👋

Je veux commander :
• Modèle : ${product}
• Quantité : ${qty}
• Total : ${total} DH

Nom : ${name}
Ville : ${city}
Adresse : ${address}

Merci !`;

  window.open("https://wa.me/212640186093?text=" + encodeURIComponent(message), "_blank");
});
