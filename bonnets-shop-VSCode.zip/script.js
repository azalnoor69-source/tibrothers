let cart = [];

function addToCart(name, price) {
  cart.push({name, price});
  document.getElementById("cartCount").textContent = cart.length;
  alert(name + " a été ajouté au panier !");
}

function openCart() {
  const modal = document.getElementById("cartModal");
  const items = document.getElementById("cartItems");
  const total = document.getElementById("cartTotal");

  items.innerHTML = cart.length
    ? cart.map((item, i) => `<div class="item"><span>${item.name}</span><strong>${item.price} DH</strong></div>`).join("")
    : "<p>Ton panier est vide.</p>";

  total.textContent = cart.reduce((sum, item) => sum + item.price, 0);
  modal.style.display = "flex";
}

function closeCart() {
  document.getElementById("cartModal").style.display = "none";
}

function checkout() {
  if (!cart.length) {
    alert("Ton panier est vide.");
    return;
  }
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const message = `Bonjour, je veux commander : ${cart.map(x => x.name).join(", ")}. Total : ${total} DH.`;
  window.open("https://wa.me/212600000000?text=" + encodeURIComponent(message), "_blank");
}
